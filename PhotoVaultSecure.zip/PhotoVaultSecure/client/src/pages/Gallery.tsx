import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import AuthModal from "@/components/AuthModal";
import PhotoGrid from "@/components/PhotoGrid";
import ConfirmationModal from "@/components/ConfirmationModal";
import SuccessModal from "@/components/SuccessModal";

import useSecurity from "@/hooks/useSecurity";
import { Camera, Check } from "lucide-react";

interface SessionData {
  id: number;
  photographerName: string;
  clientName: string;
  isLocked: boolean;
}

interface Photo {
  id: number;
  filename: string;
  imageUrl: string;
  isSelected: boolean;
}

export default function Gallery() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [sessionData, setSessionData] = useState<SessionData | null>(null);
  const [selectedPhotos, setSelectedPhotos] = useState<Set<number>>(new Set());
  const [showConfirmation, setShowConfirmation] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);

  const { } = useSecurity();

  // Fetch photos
  const { data: photosData, isLoading } = useQuery({
    queryKey: ["/api/photos"],
    enabled: isAuthenticated,
  });

  // Authentication mutation
  const authMutation = useMutation({
    mutationFn: async (token: string) => {
      const response = await apiRequest("POST", "/api/auth", { token });
      return response.json();
    },
    onSuccess: (data) => {
      setIsAuthenticated(true);
      setSessionData(data.session);
      queryClient.invalidateQueries({ queryKey: ["/api/photos"] });
    },
  });

  // Toggle photo selection mutation
  const toggleSelectionMutation = useMutation({
    mutationFn: async (photoId: number) => {
      const response = await apiRequest("POST", "/api/selections/toggle", { photoId });
      return response.json();
    },
    onSuccess: (data, photoId) => {
      const newSelected = new Set(selectedPhotos);
      if (data.selected) {
        newSelected.add(photoId);
      } else {
        newSelected.delete(photoId);
      }
      setSelectedPhotos(newSelected);
      queryClient.invalidateQueries({ queryKey: ["/api/photos"] });
    },
  });

  // Confirm selection mutation
  const confirmMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", "/api/selections/confirm");
      return response.json();
    },
    onSuccess: () => {
      setShowConfirmation(false);
      setShowSuccess(true);
      if (sessionData) {
        setSessionData({ ...sessionData, isLocked: true });
      }
    },
  });

  // Update selected photos when photos data changes
  useEffect(() => {
    if (photosData?.photos) {
      const selected = new Set<number>();
      photosData.photos.forEach((photo: Photo) => {
        if (photo.isSelected) {
          selected.add(photo.id);
        }
      });
      setSelectedPhotos(selected);
    }
  }, [photosData]);

  const handleAuth = (token: string) => {
    authMutation.mutate(token);
  };

  const handlePhotoToggle = (photoId: number) => {
    if (sessionData?.isLocked) return;
    toggleSelectionMutation.mutate(photoId);
  };

  const handleSubmitSelection = () => {
    if (selectedPhotos.size === 0) return;
    setShowConfirmation(true);
  };

  const handleConfirmSelection = () => {
    confirmMutation.mutate();
  };

  if (!isAuthenticated) {
    return (
      <>
        <AuthModal 
          onAuth={handleAuth}
          isLoading={authMutation.isPending}
          error={authMutation.error}
        />
      </>
    );
  }

  return (
    <>
      {/* Session overlay */}
      <div className="fixed top-5 right-5 text-xs text-gray-400 opacity-30 z-50 animate-pulse">
        Session: SES-2024-001
      </div>

      {/* Header */}
      <header className="bg-gray-800 border-b border-gray-700 sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-4">
              <Camera className="text-blue-500 text-xl" />
              <div>
                <h1 className="text-lg font-semibold">
                  {sessionData?.photographerName || "Studio Photography"}
                </h1>
                <p className="text-sm text-gray-400">
                  Client: {sessionData?.clientName || "Client"}
                </p>
              </div>
            </div>
            
            <div className="flex items-center space-x-4">
              <div className="text-sm text-gray-400">
                {selectedPhotos.size} selected
              </div>
              <button 
                onClick={handleSubmitSelection}
                disabled={selectedPhotos.size === 0 || sessionData?.isLocked}
                className="bg-green-600 hover:bg-green-700 disabled:bg-gray-600 disabled:cursor-not-allowed text-white px-4 py-2 rounded-lg font-medium transition-colors flex items-center space-x-2"
              >
                <Check className="w-4 h-4" />
                <span>
                  {sessionData?.isLocked ? "Selection Locked" : "Confirm Selection"}
                </span>
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Instructions */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <div className="bg-gray-800 rounded-lg p-4 mb-6">
          <div className="flex items-start space-x-3">
            <div className="w-5 h-5 rounded-full bg-blue-500 flex items-center justify-center flex-shrink-0 mt-0.5">
              <span className="text-white text-xs">i</span>
            </div>
            <div>
              <h3 className="font-medium mb-1">How to Select Your Photos</h3>
              <p className="text-sm text-gray-400">
                Click on any photo to select it as a favorite. You can select multiple photos, then click "Confirm Selection" when you're ready. 
                <strong> Note:</strong> Once confirmed, your selection cannot be changed.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Photo Grid */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-12">
        {isLoading ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {Array.from({ length: 8 }).map((_, i) => (
              <div key={i} className="aspect-square bg-gray-800 rounded-lg animate-pulse" />
            ))}
          </div>
        ) : (
          <PhotoGrid
            photos={photosData?.photos || []}
            selectedPhotos={selectedPhotos}
            onPhotoToggle={handlePhotoToggle}
            isLocked={sessionData?.isLocked || false}
            photographerName={sessionData?.photographerName || "STUDIO PHOTOGRAPHY"}
          />
        )}
      </div>

      {/* Modals */}
      <ConfirmationModal
        isOpen={showConfirmation}
        selectedCount={selectedPhotos.size}
        onCancel={() => setShowConfirmation(false)}
        onConfirm={handleConfirmSelection}
        isLoading={confirmMutation.isPending}
      />

      <SuccessModal
        isOpen={showSuccess}
        onClose={() => setShowSuccess(false)}
      />

    </>
  );
}
