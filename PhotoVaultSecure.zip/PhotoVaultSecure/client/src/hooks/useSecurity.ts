import { useEffect } from "react";

export default function useSecurity() {

  useEffect(() => {
    // Prevent screenshots by making screen black
    const preventScreenshot = () => {
      // Create black overlay
      const overlay = document.createElement('div');
      overlay.id = 'screenshot-protection';
      overlay.style.cssText = `
        position: fixed;
        top: 0;
        left: 0;
        width: 100vw;
        height: 100vh;
        background: black;
        z-index: 999999;
        pointer-events: none;
        display: none;
      `;
      document.body.appendChild(overlay);

      // Show overlay on various screenshot events
      const showOverlay = () => {
        overlay.style.display = 'block';
        setTimeout(() => {
          overlay.style.display = 'none';
        }, 3000);
      };

      return { overlay, showOverlay };
    };

    const { overlay, showOverlay } = preventScreenshot();

    // Disable right-click context menu
    const handleContextMenu = (e: MouseEvent) => {
      e.preventDefault();
    };

    // Disable common screenshot shortcuts and show black screen
    const handleKeyDown = (e: KeyboardEvent) => {
      // Print Screen, Alt+Print Screen, Windows+Print Screen
      if (e.key === 'PrintScreen' || 
          (e.altKey && e.key === 'PrintScreen') ||
          (e.metaKey && e.shiftKey && e.key === '3') ||
          (e.metaKey && e.shiftKey && e.key === '4')) {
        e.preventDefault();
        showOverlay();
        return;
      }
      
      // Disable F12, Ctrl+Shift+I, Ctrl+U
      if (e.key === 'F12' || 
          (e.ctrlKey && e.shiftKey && e.key === 'I') ||
          (e.ctrlKey && e.key === 'u')) {
        e.preventDefault();
      }
    };

    // Detect focus loss (potential screenshot via external app)
    const handleVisibilityChange = () => {
      if (document.hidden) {
        showOverlay();
      }
    };

    // Detect page blur (screenshot apps)
    const handleBlur = () => {
      showOverlay();
    };

    // Detect focus return - no need to alert
    const handleFocus = () => {
      // Just silently return focus
    };

    // Mobile screenshot detection
    const handleTouchStart = (e: TouchEvent) => {
      if (e.touches.length >= 3) {
        showOverlay();
      }
    };

    // Disable text selection
    const handleSelectStart = (e: Event) => {
      e.preventDefault();
    };

    // Disable drag
    const handleDragStart = (e: DragEvent) => {
      e.preventDefault();
    };

    // Monitor for screenshot APIs (experimental)
    if ('getDisplayMedia' in navigator.mediaDevices) {
      const originalGetDisplayMedia = navigator.mediaDevices.getDisplayMedia;
      navigator.mediaDevices.getDisplayMedia = function(...args: any[]) {
        showOverlay();
        return originalGetDisplayMedia.apply(this, args);
      };
    }

    // Additional protection: add CSS class during risky operations
    const addProtectionClass = () => {
      document.body.classList.add('screenshot-protection');
      setTimeout(() => {
        document.body.classList.remove('screenshot-protection');
      }, 2000);
    };

    // Enhanced keyboard monitoring
    const handleKeyDownEnhanced = (e: KeyboardEvent) => {
      handleKeyDown(e);
      
      // Additional screenshot combinations
      if ((e.metaKey && e.shiftKey && e.key === '5') || // Mac screenshot tools
          (e.ctrlKey && e.shiftKey && e.key === 'S') || // Windows Snipping Tool
          (e.altKey && e.key === 'Tab')) { // Alt+Tab switching
        addProtectionClass();
      }
    };

    // Add event listeners
    document.addEventListener('contextmenu', handleContextMenu);
    document.addEventListener('keydown', handleKeyDownEnhanced);
    document.addEventListener('visibilitychange', handleVisibilityChange);
    document.addEventListener('selectstart', handleSelectStart);
    document.addEventListener('dragstart', handleDragStart);
    window.addEventListener('blur', handleBlur);
    window.addEventListener('focus', handleFocus);
    document.addEventListener('touchstart', handleTouchStart);

    // Cleanup
    return () => {
      document.removeEventListener('contextmenu', handleContextMenu);
      document.removeEventListener('keydown', handleKeyDownEnhanced);
      document.removeEventListener('visibilitychange', handleVisibilityChange);
      document.removeEventListener('selectstart', handleSelectStart);
      document.removeEventListener('dragstart', handleDragStart);
      window.removeEventListener('blur', handleBlur);
      window.removeEventListener('focus', handleFocus);
      document.removeEventListener('touchstart', handleTouchStart);
      
      if (overlay && overlay.parentNode) {
        overlay.parentNode.removeChild(overlay);
      }
    };
  }, []);

  return {};
}
