import { useRef, useEffect } from "react";
import { Heart } from "lucide-react";

interface Photo {
  id: number;
  filename: string;
  imageUrl: string;
}

interface PhotoItemProps {
  photo: Photo;
  isSelected: boolean;
  onToggle: () => void;
  isLocked: boolean;
  photographerName: string;
}

export default function PhotoItem({ 
  photo, 
  isSelected, 
  onToggle, 
  isLocked, 
  photographerName 
}: PhotoItemProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const img = new Image();
    img.crossOrigin = 'anonymous';
    
    img.onload = function() {
      canvas.width = canvas.offsetWidth;
      canvas.height = canvas.offsetHeight;
      
      // Clear canvas
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      
      // Calculate aspect ratio and draw
      const aspectRatio = img.width / img.height;
      const canvasAspectRatio = canvas.width / canvas.height;
      
      let drawWidth, drawHeight, offsetX = 0, offsetY = 0;
      
      if (aspectRatio > canvasAspectRatio) {
        drawHeight = canvas.height;
        drawWidth = drawHeight * aspectRatio;
        offsetX = (canvas.width - drawWidth) / 2;
      } else {
        drawWidth = canvas.width;
        drawHeight = drawWidth / aspectRatio;
        offsetY = (canvas.height - drawHeight) / 2;
      }
      
      // Draw image
      ctx.drawImage(img, offsetX, offsetY, drawWidth, drawHeight);
      
      // Add watermark protection
      ctx.globalAlpha = 0.3;
      ctx.fillStyle = 'white';
      ctx.font = 'bold 20px Arial';
      ctx.textAlign = 'center';
      ctx.save();
      ctx.translate(canvas.width / 2, canvas.height / 2);
      ctx.rotate(Math.PI / 6);
      ctx.fillText(photographerName.toUpperCase(), 0, 0);
      ctx.restore();
      
      // Add session ID overlay
      ctx.globalAlpha = 0.1;
      ctx.fillStyle = 'red';
      ctx.font = '12px monospace';
      ctx.textAlign = 'left';
      ctx.fillText('SES-2024-001', 10, canvas.height - 10);
      
      // Reset alpha
      ctx.globalAlpha = 1.0;
    };
    
    img.onerror = function() {
      // Fallback: draw placeholder
      ctx.fillStyle = '#374151';
      ctx.fillRect(0, 0, canvas.width, canvas.height);
      ctx.fillStyle = 'white';
      ctx.font = '16px Arial';
      ctx.textAlign = 'center';
      ctx.fillText('Image not available', canvas.width / 2, canvas.height / 2);
    };
    
    img.src = photo.imageUrl;
  }, [photo.imageUrl, photographerName]);

  const handleClick = () => {
    if (isLocked) return;
    onToggle();
  };

  return (
    <div 
      className={`relative group ${isLocked ? 'cursor-not-allowed opacity-75' : 'cursor-pointer'}`}
      onClick={handleClick}
    >
      <div className="relative bg-gray-800 rounded-lg overflow-hidden aspect-square">
        {/* Canvas for secure image rendering */}
        <canvas 
          ref={canvasRef}
          className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
        />
        
        {/* Watermark overlay */}
        <div className="absolute inset-0 bg-gradient-to-br from-transparent via-transparent to-black/10 pointer-events-none">
          <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
            <div className="text-white text-lg font-semibold opacity-30 transform rotate-12 select-none">
              {photographerName.toUpperCase()}
            </div>
          </div>
        </div>
        
        {/* Selection badge */}
        <div className="absolute top-3 right-3 z-20">
          <div className={`w-8 h-8 rounded-full border-2 border-white shadow-lg flex items-center justify-center transition-all duration-300 ${
            isSelected 
              ? 'bg-green-600 opacity-100' 
              : 'bg-gray-600 opacity-0 group-hover:opacity-100'
          }`}>
            <Heart className="w-4 h-4 text-white" fill={isSelected ? "white" : "none"} />
          </div>
        </div>
        
        {/* Hover overlay */}
        <div className="absolute inset-0 bg-black opacity-0 group-hover:opacity-20 transition-opacity duration-300" />
      </div>
      
      {/* Photo metadata */}
      <div className="mt-2 text-sm text-gray-400">
        <span>{photo.filename}</span>
      </div>
    </div>
  );
}
