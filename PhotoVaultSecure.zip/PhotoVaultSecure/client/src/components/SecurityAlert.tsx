import { useState, useEffect } from "react";
import { Shield } from "lucide-react";

interface SecurityAlertProps {
  show: boolean;
  onHide: () => void;
}

function SecurityAlert({ show, onHide }: SecurityAlertProps) {
  useEffect(() => {
    if (show) {
      const timer = setTimeout(onHide, 3000);
      return () => clearTimeout(timer);
    }
  }, [show, onHide]);

  if (!show) return null;

  return (
    <div className="fixed top-4 right-4 bg-red-600 text-white px-4 py-3 rounded-lg shadow-lg z-50 animate-in slide-in-from-top-2 duration-300">
      <div className="flex items-center space-x-2">
        <Shield className="w-4 h-4" />
        <span>Screenshot attempt detected</span>
      </div>
    </div>
  );
}

export default SecurityAlert;
