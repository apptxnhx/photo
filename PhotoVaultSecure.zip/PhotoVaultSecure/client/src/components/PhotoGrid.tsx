import PhotoItem from "./PhotoItem";

interface Photo {
  id: number;
  filename: string;
  imageUrl: string;
  isSelected: boolean;
}

interface PhotoGridProps {
  photos: Photo[];
  selectedPhotos: Set<number>;
  onPhotoToggle: (photoId: number) => void;
  isLocked: boolean;
  photographerName: string;
}

export default function PhotoGrid({ 
  photos, 
  selectedPhotos, 
  onPhotoToggle, 
  isLocked, 
  photographerName 
}: PhotoGridProps) {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
      {photos.map((photo) => (
        <PhotoItem
          key={photo.id}
          photo={photo}
          isSelected={selectedPhotos.has(photo.id)}
          onToggle={() => onPhotoToggle(photo.id)}
          isLocked={isLocked}
          photographerName={photographerName}
        />
      ))}
    </div>
  );
}
