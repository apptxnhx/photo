import { Dialog, DialogContent } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { CheckCircle } from "lucide-react";

interface SuccessModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function SuccessModal({ isOpen, onClose }: SuccessModalProps) {
  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-md bg-gray-800 border-gray-700">
        <div className="text-center">
          <CheckCircle className="mx-auto text-green-500 text-4xl mb-4" />
          <h3 className="text-xl font-semibold mb-2 text-white">Selection Confirmed!</h3>
          <p className="text-gray-400 mb-6">
            Your photo selection has been sent to your photographer. You will receive confirmation via email shortly.
          </p>
          
          <Button 
            onClick={onClose}
            className="w-full bg-blue-600 hover:bg-blue-700 text-white"
          >
            Close
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
