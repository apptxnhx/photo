import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Camera } from "lucide-react";

interface AuthModalProps {
  onAuth: (token: string) => void;
  isLoading: boolean;
  error: Error | null;
}

export default function AuthModal({ onAuth, isLoading, error }: AuthModalProps) {
  const [accessCode, setAccessCode] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (accessCode.trim()) {
      onAuth(accessCode.trim());
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50 p-4">
      <div className="bg-gray-800 border border-gray-700 rounded-xl shadow-2xl p-8 max-w-md w-full transform transition-all duration-300 ease-out">
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-16 h-16 bg-blue-600 rounded-full mb-4">
            <Camera className="text-white text-2xl" />
          </div>
          <h2 className="text-2xl font-bold mb-2 text-white">Acesso à Galeria</h2>
          <p className="text-gray-400">Digite seu código de acesso para visualizar suas fotos</p>
        </div>
        
        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <Label htmlFor="accessCode" className="text-white font-medium">Código de Acesso</Label>
            <Input 
              id="accessCode"
              type="password"
              value={accessCode}
              onChange={(e) => setAccessCode(e.target.value)}
              placeholder="Digite seu código único"
              className="mt-2 bg-gray-700 border-gray-600 text-white placeholder-gray-400 focus:ring-blue-500 focus:border-blue-500 h-12 text-center text-lg tracking-wider"
              disabled={isLoading}
              autoFocus
            />
            {error && (
              <p className="text-red-400 text-sm mt-2 text-center">
                Código de acesso inválido. Tente novamente.
              </p>
            )}
          </div>
          
          <Button 
            type="submit"
            disabled={!accessCode.trim() || isLoading}
            className="w-full bg-blue-600 hover:bg-blue-700 disabled:bg-gray-600 text-white h-12 text-lg font-medium transition-all duration-200"
          >
            {isLoading ? "Autenticando..." : "Acessar Galeria"}
          </Button>
        </form>
        
        <div className="mt-8 text-center text-sm text-gray-400">
          <p>Problemas para acessar? Entre em contato com seu fotógrafo.</p>
          <div className="mt-4 text-xs text-gray-500">
            <p>Código demo: <span className="font-mono bg-gray-700 px-2 py-1 rounded">DEMO2024</span></p>
          </div>
        </div>
      </div>
    </div>
  );
}
