import { Dialog, DialogContent } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { AlertTriangle } from "lucide-react";

interface ConfirmationModalProps {
  isOpen: boolean;
  selectedCount: number;
  onCancel: () => void;
  onConfirm: () => void;
  isLoading: boolean;
}

export default function ConfirmationModal({
  isOpen,
  selectedCount,
  onCancel,
  onConfirm,
  isLoading
}: ConfirmationModalProps) {
  return (
    <Dialog open={isOpen} onOpenChange={onCancel}>
      <DialogContent className="max-w-md bg-gray-800 border-gray-700">
        <div className="text-center">
          <AlertTriangle className="mx-auto text-yellow-500 text-4xl mb-4" />
          <h3 className="text-xl font-semibold mb-2 text-white">Confirm Your Selection</h3>
          <p className="text-gray-400 mb-6">
            You have selected <span className="text-blue-500 font-medium">{selectedCount}</span> photos. 
            Once confirmed, you cannot change your selection.
          </p>
          
          <div className="flex space-x-3">
            <Button 
              onClick={onCancel}
              variant="outline"
              className="flex-1 bg-gray-600 hover:bg-gray-700 text-white border-gray-600"
              disabled={isLoading}
            >
              Cancel
            </Button>
            <Button 
              onClick={onConfirm}
              className="flex-1 bg-green-600 hover:bg-green-700 text-white"
              disabled={isLoading}
            >
              {isLoading ? "Confirming..." : "Confirm"}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
