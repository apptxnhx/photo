import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertSelectionSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Authentication endpoint
  app.post("/api/auth", async (req, res) => {
    try {
      const { token } = req.body;
      
      if (!token) {
        return res.status(400).json({ message: "Access token is required" });
      }

      const session = await storage.getSessionByToken(token);
      
      if (!session) {
        return res.status(401).json({ message: "Invalid or expired access token" });
      }

      // Store session in request session
      (req as any).session = { sessionId: session.id };
      
      res.json({
        success: true,
        session: {
          id: session.id,
          photographerName: session.photographerName,
          clientName: session.clientName,
          isLocked: session.isLocked,
        }
      });
    } catch (error) {
      res.status(500).json({ message: "Authentication failed" });
    }
  });

  // Get photos for session
  app.get("/api/photos", async (req, res) => {
    try {
      const sessionId = (req as any).session?.sessionId;
      
      if (!sessionId) {
        return res.status(401).json({ message: "Authentication required" });
      }

      const photos = await storage.getPhotosBySession(sessionId);
      const selections = await storage.getSelectionsBySession(sessionId);
      const selectedPhotoIds = selections.map(s => s.photoId);

      res.json({
        photos: photos.map(photo => ({
          ...photo,
          isSelected: selectedPhotoIds.includes(photo.id)
        }))
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch photos" });
    }
  });

  // Get current selections
  app.get("/api/selections", async (req, res) => {
    try {
      const sessionId = (req as any).session?.sessionId;
      
      if (!sessionId) {
        return res.status(401).json({ message: "Authentication required" });
      }

      const selections = await storage.getSelectionsBySession(sessionId);
      res.json({ selections });
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch selections" });
    }
  });

  // Toggle photo selection
  app.post("/api/selections/toggle", async (req, res) => {
    try {
      const sessionId = (req as any).session?.sessionId;
      
      if (!sessionId) {
        return res.status(401).json({ message: "Authentication required" });
      }

      const { photoId } = req.body;
      
      if (!photoId) {
        return res.status(400).json({ message: "Photo ID is required" });
      }

      // Check if session is locked
      const session = await storage.getSessionByToken('DEMO2024'); // In real app, get from session
      if (session?.isLocked) {
        return res.status(403).json({ message: "Selection is locked" });
      }

      const selections = await storage.getSelectionsBySession(sessionId);
      const existingSelection = selections.find(s => s.photoId === photoId);

      if (existingSelection) {
        // Remove selection (toggle off)
        await storage.deleteSelectionsBySession(sessionId);
        const remainingSelections = selections.filter(s => s.photoId !== photoId);
        
        // Re-add remaining selections
        for (const selection of remainingSelections) {
          await storage.createSelection({
            sessionId: selection.sessionId,
            photoId: selection.photoId,
          });
        }
        
        res.json({ selected: false });
      } else {
        // Add selection (toggle on)
        await storage.createSelection({
          sessionId,
          photoId: parseInt(photoId),
        });
        
        res.json({ selected: true });
      }
    } catch (error) {
      res.status(500).json({ message: "Failed to toggle selection" });
    }
  });

  // Confirm final selection
  app.post("/api/selections/confirm", async (req, res) => {
    try {
      const sessionId = (req as any).session?.sessionId;
      
      if (!sessionId) {
        return res.status(401).json({ message: "Authentication required" });
      }

      // Lock the session
      await storage.lockSession(sessionId);

      // In a real implementation, send email notification here
      console.log(`Photo selection confirmed for session ${sessionId}`);

      res.json({ success: true, message: "Selection confirmed successfully" });
    } catch (error) {
      res.status(500).json({ message: "Failed to confirm selection" });
    }
  });

  // Session middleware to handle authentication state
  app.use((req, res, next) => {
    // Simple session simulation - in production, use proper session management
    if (req.headers.authorization) {
      const token = req.headers.authorization.replace('Bearer ', '');
      storage.getSessionByToken(token).then(session => {
        if (session) {
          (req as any).session = { sessionId: session.id };
        }
        next();
      }).catch(() => next());
    } else {
      next();
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
