import { sessions, photos, selections, type Session, type Photo, type Selection, type InsertSession, type InsertPhoto, type InsertSelection } from "@shared/schema";

export interface IStorage {
  // Session management
  createSession(session: InsertSession): Promise<Session>;
  getSessionByToken(token: string): Promise<Session | undefined>;
  lockSession(sessionId: number): Promise<void>;
  
  // Photo management
  getPhotosBySession(sessionId: number): Promise<Photo[]>;
  createPhoto(photo: InsertPhoto): Promise<Photo>;
  
  // Selection management
  createSelection(selection: InsertSelection): Promise<Selection>;
  getSelectionsBySession(sessionId: number): Promise<Selection[]>;
  deleteSelectionsBySession(sessionId: number): Promise<void>;
}

export class MemStorage implements IStorage {
  private sessions: Map<number, Session>;
  private photos: Map<number, Photo>;
  private selections: Map<number, Selection>;
  private currentSessionId: number;
  private currentPhotoId: number;
  private currentSelectionId: number;

  constructor() {
    this.sessions = new Map();
    this.photos = new Map();
    this.selections = new Map();
    this.currentSessionId = 1;
    this.currentPhotoId = 1;
    this.currentSelectionId = 1;
    
    // Initialize with demo data
    this.initializeDemoData();
  }

  private initializeDemoData() {
    // Create demo session
    const demoSession: Session = {
      id: 1,
      token: 'DEMO2024',
      photographerName: 'Studio Photography',
      clientName: 'Sarah Johnson',
      isLocked: false,
      expiresAt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000), // 7 days from now
      createdAt: new Date(),
    };
    this.sessions.set(1, demoSession);
    this.currentSessionId = 2;

    // Create demo photos
    const demoPhotos = [
      'https://images.unsplash.com/photo-1542273917363-3b1817f69a2d?w=800&h=800&fit=crop&crop=center',
      'https://images.unsplash.com/photo-1494790108755-2616b332c777?w=800&h=800&fit=crop&crop=center',
      'https://images.unsplash.com/photo-1511285560929-80b456fea0bc?w=800&h=800&fit=crop&crop=center',
      'https://images.unsplash.com/photo-1519741497674-611481863552?w=800&h=800&fit=crop&crop=center',
      'https://images.unsplash.com/photo-1511895426328-dc8714191300?w=800&h=800&fit=crop&crop=center',
      'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=800&h=800&fit=crop&crop=center',
      'https://images.unsplash.com/photo-1529626455594-4ff0802cfb7e?w=800&h=800&fit=crop&crop=center',
      'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?w=800&h=800&fit=crop&crop=center',
      'https://images.unsplash.com/photo-1488426862026-3ee34a7d66df?w=800&h=800&fit=crop&crop=center',
      'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=800&h=800&fit=crop&crop=center',
      'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=800&h=800&fit=crop&crop=center',
      'https://images.unsplash.com/photo-1531123897727-8f129e1688ce?w=800&h=800&fit=crop&crop=center'
    ];

    demoPhotos.forEach((url, index) => {
      const photo: Photo = {
        id: index + 1,
        sessionId: 1,
        filename: `IMG_${String(index + 1).padStart(3, '0')}.jpg`,
        imageUrl: url,
        order: index,
      };
      this.photos.set(index + 1, photo);
    });
    this.currentPhotoId = demoPhotos.length + 1;
  }

  async createSession(insertSession: InsertSession): Promise<Session> {
    const id = this.currentSessionId++;
    const session: Session = {
      ...insertSession,
      id,
      createdAt: new Date(),
      isLocked: insertSession.isLocked ?? false,
    };
    this.sessions.set(id, session);
    return session;
  }

  async getSessionByToken(token: string): Promise<Session | undefined> {
    return Array.from(this.sessions.values()).find(
      (session) => session.token === token && session.expiresAt > new Date()
    );
  }

  async lockSession(sessionId: number): Promise<void> {
    const session = this.sessions.get(sessionId);
    if (session) {
      session.isLocked = true;
      this.sessions.set(sessionId, session);
    }
  }

  async getPhotosBySession(sessionId: number): Promise<Photo[]> {
    return Array.from(this.photos.values())
      .filter((photo) => photo.sessionId === sessionId)
      .sort((a, b) => (a.order || 0) - (b.order || 0));
  }

  async createPhoto(insertPhoto: InsertPhoto): Promise<Photo> {
    const id = this.currentPhotoId++;
    const photo: Photo = { 
      ...insertPhoto, 
      id,
      order: insertPhoto.order ?? 0
    };
    this.photos.set(id, photo);
    return photo;
  }

  async createSelection(insertSelection: InsertSelection): Promise<Selection> {
    const id = this.currentSelectionId++;
    const selection: Selection = {
      ...insertSelection,
      id,
      selectedAt: new Date(),
    };
    this.selections.set(id, selection);
    return selection;
  }

  async getSelectionsBySession(sessionId: number): Promise<Selection[]> {
    return Array.from(this.selections.values()).filter(
      (selection) => selection.sessionId === sessionId
    );
  }

  async deleteSelectionsBySession(sessionId: number): Promise<void> {
    const toDelete = Array.from(this.selections.entries())
      .filter(([_, selection]) => selection.sessionId === sessionId)
      .map(([id]) => id);
    
    toDelete.forEach(id => this.selections.delete(id));
  }
}

export const storage = new MemStorage();
